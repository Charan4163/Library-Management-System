# Library Desk — Library Management System

A React + Vite app for running a small library: manage books and members, issue and return books, and track overdue loans and fines. Data is saved in the browser (localStorage), so no backend is needed.

## Run it

```bash
npm install
npm run dev
```

Open the local URL Vite prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
npm run preview
```

## Features

- **Dashboard**: titles, copies on shelf, members, books out, overdue count; overdue list with fines; recent activity
- **Books**: add, edit, delete; search by title, author or ISBN; filter by category; live availability
- **Members**: add, edit, delete; see how many books each member has out
- **Loans**: issue a book (14-day loan, max 3 per member), return it, see fines for late returns, filter by status

## Settings

Loan length, fine per day, and the per-member limit live in `src/lib/constants.js`.

## Reset the demo data

Open the browser console and run `localStorage.clear()`, then reload.

## Project structure

```
src/
  App.jsx              state, actions, navigation
  components/          Dashboard, Books, Members, Loans, Modal
  hooks/               useLocalStorage
  lib/                 constants, date helpers, loan helpers
  data/seed.js         starter books, members and loans
```
