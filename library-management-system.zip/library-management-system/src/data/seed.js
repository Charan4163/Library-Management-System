import { LOAN_DAYS } from '../lib/constants'
import { addDays, today } from '../lib/dates'

export const seedBooks = () => [
  { id: 'b1', title: 'Wings of Fire', author: 'A. P. J. Abdul Kalam', isbn: '', category: 'Biography', copies: 2 },
  { id: 'b2', title: 'The Discovery of India', author: 'Jawaharlal Nehru', isbn: '', category: 'History', copies: 1 },
  { id: 'b3', title: 'Clean Code', author: 'Robert C. Martin', isbn: '', category: 'Technology', copies: 1 },
  { id: 'b4', title: 'A Brief History of Time', author: 'Stephen Hawking', isbn: '', category: 'Science', copies: 2 },
  { id: 'b5', title: 'The Guide', author: 'R. K. Narayan', isbn: '', category: 'Fiction', copies: 3 },
  { id: 'b6', title: 'Introduction to Algorithms', author: 'Cormen, Leiserson, Rivest, Stein', isbn: '', category: 'Technology', copies: 2 },
  { id: 'b7', title: 'Godan', author: 'Premchand', isbn: '', category: 'Fiction', copies: 2 },
  { id: 'b8', title: 'Sapiens', author: 'Yuval Noah Harari', isbn: '', category: 'History', copies: 2 },
]

export const seedMembers = () => [
  { id: 'm1', name: 'Aarav Sharma', email: 'aarav@example.com', phone: '98450 11001' },
  { id: 'm2', name: 'Priya Nair', email: 'priya@example.com', phone: '98450 11002' },
  { id: 'm3', name: 'Rohan Mehta', email: 'rohan@example.com', phone: '98450 11003' },
  { id: 'm4', name: 'Ananya Iyer', email: 'ananya@example.com', phone: '98450 11004' },
]

const ago = (n) => addDays(today(), -n)

export const seedLoans = () => [
  { id: 'l1', bookId: 'b3', memberId: 'm1', issuedOn: ago(20), dueOn: addDays(ago(20), LOAN_DAYS), returnedOn: null },
  { id: 'l2', bookId: 'b4', memberId: 'm2', issuedOn: ago(3), dueOn: addDays(ago(3), LOAN_DAYS), returnedOn: null },
  { id: 'l3', bookId: 'b5', memberId: 'm3', issuedOn: ago(30), dueOn: addDays(ago(30), LOAN_DAYS), returnedOn: ago(14) },
  { id: 'l4', bookId: 'b1', memberId: 'm4', issuedOn: ago(10), dueOn: addDays(ago(10), LOAN_DAYS), returnedOn: null },
]
