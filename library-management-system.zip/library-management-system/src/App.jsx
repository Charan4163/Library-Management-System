import { useState } from 'react'
import Books from './components/Books'
import Dashboard from './components/Dashboard'
import Loans from './components/Loans'
import Members from './components/Members'
import { seedBooks, seedLoans, seedMembers } from './data/seed'
import useLocalStorage from './hooks/useLocalStorage'
import { LOAN_DAYS, MAX_LOANS_PER_MEMBER } from './lib/constants'
import { addDays, today } from './lib/dates'
import { uid } from './lib/ids'
import { activeLoansOf, copiesOut } from './lib/loans'

const NAV = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'books', label: 'Books' },
  { id: 'members', label: 'Members' },
  { id: 'loans', label: 'Loans' },
]

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [books, setBooks] = useLocalStorage('lib.books', seedBooks)
  const [members, setMembers] = useLocalStorage('lib.members', seedMembers)
  const [loans, setLoans] = useLocalStorage('lib.loans', seedLoans)

  const addBook = (data) => setBooks([...books, { ...data, id: uid() }])
  const updateBook = (id, data) =>
    setBooks(books.map((b) => (b.id === id ? { ...b, ...data } : b)))
  const deleteBook = (id) => setBooks(books.filter((b) => b.id !== id))

  const addMember = (data) => setMembers([...members, { ...data, id: uid() }])
  const updateMember = (id, data) =>
    setMembers(members.map((m) => (m.id === id ? { ...m, ...data } : m)))
  const deleteMember = (id) => setMembers(members.filter((m) => m.id !== id))

  // Returns an error message, or null when the book was issued.
  const issueBook = (bookId, memberId) => {
    const book = books.find((b) => b.id === bookId)
    const member = members.find((m) => m.id === memberId)
    if (!book || !member) return 'Choose a member and a book.'
    if (book.copies - copiesOut(bookId, loans) <= 0) return 'No copies of this book are available.'
    if (activeLoansOf(memberId, loans).length >= MAX_LOANS_PER_MEMBER) {
      return `${member.name} already has ${MAX_LOANS_PER_MEMBER} books out. Ask them to return one first.`
    }
    const issuedOn = today()
    setLoans([
      ...loans,
      { id: uid(), bookId, memberId, issuedOn, dueOn: addDays(issuedOn, LOAN_DAYS), returnedOn: null },
    ])
    return null
  }

  const returnBook = (loanId) =>
    setLoans(loans.map((l) => (l.id === loanId ? { ...l, returnedOn: today() } : l)))

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true" />
          Library Desk
        </div>
        <nav aria-label="Main">
          {NAV.map((n) => (
            <button
              key={n.id}
              className={page === n.id ? 'nav on' : 'nav'}
              aria-current={page === n.id ? 'page' : undefined}
              onClick={() => setPage(n.id)}
            >
              {n.label}
            </button>
          ))}
        </nav>
      </aside>

      <main className="main">
        {page === 'dashboard' && (
          <Dashboard books={books} members={members} loans={loans} onNavigate={setPage} />
        )}
        {page === 'books' && (
          <Books
            books={books}
            loans={loans}
            onAdd={addBook}
            onUpdate={updateBook}
            onDelete={deleteBook}
          />
        )}
        {page === 'members' && (
          <Members
            members={members}
            loans={loans}
            onAdd={addMember}
            onUpdate={updateMember}
            onDelete={deleteMember}
          />
        )}
        {page === 'loans' && (
          <Loans
            books={books}
            members={members}
            loans={loans}
            onIssue={issueBook}
            onReturn={returnBook}
          />
        )}
      </main>
    </div>
  )
}
