import { useState } from 'react'
import { CATEGORIES, SPINE } from '../lib/constants'
import { copiesOut } from '../lib/loans'
import Modal from './Modal'

const blank = { title: '', author: '', isbn: '', category: 'Fiction', copies: 1 }

function BookForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState(initial)
  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value })

  const submit = (e) => {
    e.preventDefault()
    onSave({
      ...form,
      title: form.title.trim(),
      author: form.author.trim(),
      isbn: form.isbn.trim(),
      copies: Math.max(1, Number(form.copies) || 1),
    })
  }

  return (
    <form onSubmit={submit} className="form">
      <label>
        Title
        <input value={form.title} onChange={set('title')} required autoFocus />
      </label>
      <label>
        Author
        <input value={form.author} onChange={set('author')} required />
      </label>
      <div className="form-row">
        <label>
          Category
          <select value={form.category} onChange={set('category')}>
            {CATEGORIES.map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
        </label>
        <label>
          Copies
          <input type="number" min="1" value={form.copies} onChange={set('copies')} required />
        </label>
      </div>
      <label>
        ISBN (optional)
        <input value={form.isbn} onChange={set('isbn')} />
      </label>
      <div className="form-actions">
        <button type="button" className="btn" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn primary">
          Save book
        </button>
      </div>
    </form>
  )
}

export default function Books({ books, loans, onAdd, onUpdate, onDelete }) {
  const [query, setQuery] = useState('')
  const [category, setCategory] = useState('All')
  const [editing, setEditing] = useState(null) // null | 'new' | book

  const q = query.trim().toLowerCase()
  const shown = books.filter(
    (b) =>
      (category === 'All' || b.category === category) &&
      (!q ||
        b.title.toLowerCase().includes(q) ||
        b.author.toLowerCase().includes(q) ||
        b.isbn.toLowerCase().includes(q)),
  )

  const save = (data) => {
    if (editing === 'new') onAdd(data)
    else onUpdate(editing.id, data)
    setEditing(null)
  }

  const remove = (book) => {
    if (copiesOut(book.id, loans) > 0) {
      alert('This book has copies on loan. Return them before deleting it.')
      return
    }
    if (confirm(`Delete "${book.title}"?`)) onDelete(book.id)
  }

  return (
    <section>
      <header className="page-head">
        <h1>Books</h1>
        <button className="btn primary" onClick={() => setEditing('new')}>
          Add book
        </button>
      </header>

      <div className="toolbar">
        <input
          type="search"
          placeholder="Search title, author or ISBN"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Search books"
        />
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          aria-label="Filter by category"
        >
          <option>All</option>
          {CATEGORIES.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Book</th>
              <th>Category</th>
              <th>ISBN</th>
              <th>Available</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {shown.map((b) => {
              const out = copiesOut(b.id, loans)
              const free = b.copies - out
              return (
                <tr key={b.id}>
                  <td>
                    <div className="book-cell">
                      <span className="spine" style={{ background: SPINE[b.category] }} />
                      <div>
                        <strong>{b.title}</strong>
                        <span className="sub">{b.author}</span>
                      </div>
                    </div>
                  </td>
                  <td>{b.category}</td>
                  <td>{b.isbn || '—'}</td>
                  <td>
                    <span className={free === 0 ? 'pill none' : 'pill ok'}>
                      {free} of {b.copies}
                    </span>
                  </td>
                  <td className="actions">
                    <button className="link" onClick={() => setEditing(b)}>
                      Edit
                    </button>
                    <button className="link danger" onClick={() => remove(b)}>
                      Delete
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {shown.length === 0 && (
          <p className="empty">
            {books.length === 0
              ? 'No books yet. Add your first book.'
              : 'No books match your search.'}
          </p>
        )}
      </div>

      {editing && (
        <Modal title={editing === 'new' ? 'Add book' : 'Edit book'} onClose={() => setEditing(null)}>
          <BookForm
            initial={editing === 'new' ? blank : editing}
            onSave={save}
            onCancel={() => setEditing(null)}
          />
        </Modal>
      )}
    </section>
  )
}
