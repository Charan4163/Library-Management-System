import { formatDate, today } from '../lib/dates'
import { fineFor, isActive, overdueDays, rupees } from '../lib/loans'

export default function Dashboard({ books, members, loans, onNavigate }) {
  const active = loans.filter(isActive)
  const overdue = active
    .filter((l) => l.dueOn < today())
    .sort((a, b) => overdueDays(b) - overdueDays(a))
  const totalCopies = books.reduce((sum, b) => sum + b.copies, 0)
  const recent = [...loans]
    .sort((a, b) => b.issuedOn.localeCompare(a.issuedOn))
    .slice(0, 5)

  const titleOf = (id) => books.find((b) => b.id === id)?.title ?? 'Deleted book'
  const nameOf = (id) => members.find((m) => m.id === id)?.name ?? 'Deleted member'

  const stats = [
    { label: 'Titles', value: books.length },
    { label: 'On the shelf', value: totalCopies - active.length },
    { label: 'Out on loan', value: active.length },
    { label: 'Overdue', value: overdue.length, alert: overdue.length > 0 },
    { label: 'Members', value: members.length },
  ]

  return (
    <section>
      <header className="page-head">
        <h1>Dashboard</h1>
        <button className="btn primary" onClick={() => onNavigate('loans')}>
          Issue a book
        </button>
      </header>

      <dl className="stats">
        {stats.map((s) => (
          <div key={s.label} className={s.alert ? 'stat alert' : 'stat'}>
            <dd>{s.value}</dd>
            <dt>{s.label}</dt>
          </div>
        ))}
      </dl>

      <div className="two-col">
        <div className="panel">
          <h2>Overdue books</h2>
          {overdue.length === 0 ? (
            <p className="empty">Nothing is overdue.</p>
          ) : (
            <ul className="rows">
              {overdue.map((l) => (
                <li key={l.id}>
                  <div>
                    <strong>{titleOf(l.bookId)}</strong>
                    <span className="sub">
                      {nameOf(l.memberId)} · due {formatDate(l.dueOn)}
                    </span>
                  </div>
                  <div className="right danger">
                    {overdueDays(l)} days late
                    <span className="sub">Fine {rupees(fineFor(l))}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="panel">
          <h2>Recent loans</h2>
          {recent.length === 0 ? (
            <p className="empty">No loans yet. Issue a book to get started.</p>
          ) : (
            <ul className="rows">
              {recent.map((l) => (
                <li key={l.id}>
                  <div>
                    <strong>{titleOf(l.bookId)}</strong>
                    <span className="sub">{nameOf(l.memberId)}</span>
                  </div>
                  <div className="right">
                    {l.returnedOn ? 'Returned' : `Due ${formatDate(l.dueOn)}`}
                    <span className="sub">Issued {formatDate(l.issuedOn)}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </section>
  )
}
