import { useState } from 'react'
import { activeLoansOf } from '../lib/loans'
import Modal from './Modal'

const blank = { name: '', email: '', phone: '' }

function MemberForm({ initial, onSave, onCancel }) {
  const [form, setForm] = useState(initial)
  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value })

  const submit = (e) => {
    e.preventDefault()
    onSave({
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
    })
  }

  return (
    <form onSubmit={submit} className="form">
      <label>
        Full name
        <input value={form.name} onChange={set('name')} required autoFocus />
      </label>
      <label>
        Email
        <input type="email" value={form.email} onChange={set('email')} required />
      </label>
      <label>
        Phone
        <input value={form.phone} onChange={set('phone')} />
      </label>
      <div className="form-actions">
        <button type="button" className="btn" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn primary">
          Save member
        </button>
      </div>
    </form>
  )
}

export default function Members({ members, loans, onAdd, onUpdate, onDelete }) {
  const [query, setQuery] = useState('')
  const [editing, setEditing] = useState(null)

  const q = query.trim().toLowerCase()
  const shown = members.filter(
    (m) => !q || m.name.toLowerCase().includes(q) || m.email.toLowerCase().includes(q),
  )

  const save = (data) => {
    if (editing === 'new') onAdd(data)
    else onUpdate(editing.id, data)
    setEditing(null)
  }

  const remove = (member) => {
    if (activeLoansOf(member.id, loans).length > 0) {
      alert('This member still has books out. Return them before deleting the member.')
      return
    }
    if (confirm(`Delete ${member.name}?`)) onDelete(member.id)
  }

  return (
    <section>
      <header className="page-head">
        <h1>Members</h1>
        <button className="btn primary" onClick={() => setEditing('new')}>
          Add member
        </button>
      </header>

      <div className="toolbar">
        <input
          type="search"
          placeholder="Search name or email"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label="Search members"
        />
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Books out</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {shown.map((m) => (
              <tr key={m.id}>
                <td>
                  <strong>{m.name}</strong>
                </td>
                <td>{m.email}</td>
                <td>{m.phone || '—'}</td>
                <td>{activeLoansOf(m.id, loans).length}</td>
                <td className="actions">
                  <button className="link" onClick={() => setEditing(m)}>
                    Edit
                  </button>
                  <button className="link danger" onClick={() => remove(m)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {shown.length === 0 && (
          <p className="empty">
            {members.length === 0
              ? 'No members yet. Add your first member.'
              : 'No members match your search.'}
          </p>
        )}
      </div>

      {editing && (
        <Modal title={editing === 'new' ? 'Add member' : 'Edit member'} onClose={() => setEditing(null)}>
          <MemberForm
            initial={editing === 'new' ? blank : editing}
            onSave={save}
            onCancel={() => setEditing(null)}
          />
        </Modal>
      )}
    </section>
  )
}
