import { useState } from 'react'
import { LOAN_DAYS } from '../lib/constants'
import { addDays, formatDate, today } from '../lib/dates'
import { copiesOut, fineFor, isActive, overdueDays, rupees } from '../lib/loans'

export default function Loans({ books, members, loans, onIssue, onReturn }) {
  const [memberId, setMemberId] = useState('')
  const [bookId, setBookId] = useState('')
  const [filter, setFilter] = useState('active')
  const [message, setMessage] = useState(null) // { type, text }

  const available = books.filter((b) => b.copies - copiesOut(b.id, loans) > 0)

  const titleOf = (id) => books.find((b) => b.id === id)?.title ?? 'Deleted book'
  const nameOf = (id) => members.find((m) => m.id === id)?.name ?? 'Deleted member'

  const issue = (e) => {
    e.preventDefault()
    const error = onIssue(bookId, memberId)
    if (error) {
      setMessage({ type: 'error', text: error })
      return
    }
    setMessage({
      type: 'ok',
      text: `Issued "${titleOf(bookId)}" to ${nameOf(memberId)}. Due ${formatDate(addDays(today(), LOAN_DAYS))}.`,
    })
    setBookId('')
  }

  const giveBack = (loan) => {
    const fine = fineFor(loan)
    onReturn(loan.id)
    setMessage({
      type: fine > 0 ? 'error' : 'ok',
      text:
        fine > 0
          ? `Returned "${titleOf(loan.bookId)}". Collect a fine of ${rupees(fine)}.`
          : `Returned "${titleOf(loan.bookId)}". No fine.`,
    })
  }

  const shown = loans
    .filter((l) => {
      if (filter === 'active') return isActive(l)
      if (filter === 'overdue') return isActive(l) && l.dueOn < today()
      if (filter === 'returned') return !isActive(l)
      return true
    })
    .sort((a, b) => b.issuedOn.localeCompare(a.issuedOn))

  return (
    <section>
      <header className="page-head">
        <h1>Loans</h1>
      </header>

      <form className="panel issue" onSubmit={issue}>
        <h2>Issue a book</h2>
        <div className="issue-row">
          <label>
            Member
            <select value={memberId} onChange={(e) => setMemberId(e.target.value)} required>
              <option value="">Choose a member</option>
              {members.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            Book
            <select value={bookId} onChange={(e) => setBookId(e.target.value)} required>
              <option value="">Choose a book</option>
              {available.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.title}
                </option>
              ))}
            </select>
          </label>
          <button type="submit" className="btn primary">
            Issue book
          </button>
        </div>
        <p className="hint">
          Loans run {LOAN_DAYS} days. A book issued today is due {formatDate(addDays(today(), LOAN_DAYS))}.
        </p>
        {message && (
          <p role="status" className={`notice ${message.type}`}>
            {message.text}
          </p>
        )}
      </form>

      <div className="toolbar">
        <div className="tabs" role="group" aria-label="Filter loans">
          {['active', 'overdue', 'returned', 'all'].map((f) => (
            <button
              key={f}
              className={filter === f ? 'tab on' : 'tab'}
              aria-pressed={filter === f}
              onClick={() => setFilter(f)}
            >
              {f[0].toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Book</th>
              <th>Member</th>
              <th>Issued</th>
              <th>Due</th>
              <th>Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {shown.map((l) => {
              const late = overdueDays(l)
              return (
                <tr key={l.id}>
                  <td>
                    <strong>{titleOf(l.bookId)}</strong>
                  </td>
                  <td>{nameOf(l.memberId)}</td>
                  <td>{formatDate(l.issuedOn)}</td>
                  <td>{formatDate(l.dueOn)}</td>
                  <td>
                    {l.returnedOn ? (
                      <span className="pill none">
                        Returned {formatDate(l.returnedOn)}
                        {late > 0 && ` · fine ${rupees(fineFor(l))}`}
                      </span>
                    ) : late > 0 ? (
                      <span className="pill late">
                        {late} days late · fine {rupees(fineFor(l))}
                      </span>
                    ) : (
                      <span className="pill ok">On time</span>
                    )}
                  </td>
                  <td className="actions">
                    {isActive(l) && (
                      <button className="btn small" onClick={() => giveBack(l)}>
                        Return
                      </button>
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {shown.length === 0 && <p className="empty">No loans in this view.</p>}
      </div>
    </section>
  )
}
